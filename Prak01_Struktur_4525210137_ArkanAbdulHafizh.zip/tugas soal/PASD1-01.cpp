// 1. Menampilkan SIM Anda masing-masing yang menampilkan 
// (Nama, Alamat, Tahun Lahir, Tinggi, Pekerjaan, Nomor SIM, 
// Masa Berlaku SIM) tanpa menggunakan perintah input dan nama 
// struktur adalah nama panggilan Anda Masing-masing

// Nama : Arkan Abdul Hafizh
// NPM : 4525210137
// Date : 7-4-2026

#include <iostream>
#include <string>
using namespace std;

struct Arkan {
    string nama;
    string alamat;
    int tahun_lahir;
    float tinggi;
    string pekerjaan;
    string nomor_sim;
    string masa_berlaku;
};

int main() {
    struct Arkan sim1;

    cout << "========================================" << endl;
    cout << "         INPUT DATA SIM                 " << endl;
    cout << "========================================" << endl;

    cout << "Nama         : ";
    getline(cin, sim1.nama);

    cout << "Alamat       : ";
    getline(cin, sim1.alamat);

    cout << "Tahun Lahir  : ";
    cin >> sim1.tahun_lahir;

    cout << "Tinggi (cm)  : ";
    cin >> sim1.tinggi;

    cout << "Pekerjaan    : ";
    cin >> sim1.pekerjaan;

    cout << "Nomor SIM    : ";
    cin >> sim1.nomor_sim;

    cout << "Masa Berlaku : ";
    cin >> sim1.masa_berlaku;

    cout << endl;
    cout << "========================================" << endl;
    cout << "         SURAT IZIN MENGEMUDI           " << endl;
    cout << "========================================" << endl;
    cout << "Nama         : " << sim1.nama         << endl;
    cout << "Alamat       : " << sim1.alamat        << endl;
    cout << "Tahun Lahir  : " << sim1.tahun_lahir   << endl;
    cout << "Tinggi       : " << sim1.tinggi << " cm" << endl;
    cout << "Pekerjaan    : " << sim1.pekerjaan     << endl;
    cout << "Nomor SIM    : " << sim1.nomor_sim     << endl;
    cout << "Masa Berlaku : " << sim1.masa_berlaku  << endl;
    cout << "========================================" << endl;

    cin.get();
}