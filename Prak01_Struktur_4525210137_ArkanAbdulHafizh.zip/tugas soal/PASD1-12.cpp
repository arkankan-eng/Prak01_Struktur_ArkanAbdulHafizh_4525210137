#include <iostream>
#include <string>
using namespace std;

struct KTP {
    int NOKTP;
    string Nama;
    struct Alamat {
        string Jalan;
        string Kota;
        int KodePos;
    } Alamat;
    struct Lahir {
        int Tanggal;
        int Bulan;
        int Tahun;
    } Lahir;
};

int main() {
    KTP JatiDiri;
    KTP *p = &JatiDiri;

    cout << "Masukkan No KTP  = "; cin >> p->NOKTP;
    cout << "Masukkan Nama    = "; cin >> p->Nama;
    cout << "Alamat" << endl;
    cout << " - Jalan         = "; cin >> p->Alamat.Jalan;
    cout << " - Kota          = "; cin >> p->Alamat.Kota;
    cout << " - Kode Pos      = "; cin >> p->Alamat.KodePos;
    cout << "Tanggal Lahir" << endl;
    cout << " - Tanggal       = "; cin >> p->Lahir.Tanggal;
    cout << " - Bulan         = "; cin >> p->Lahir.Bulan;
    cout << " - Tahun         = "; cin >> p->Lahir.Tahun;

    cout << endl;
    cout << endl;

    // Output Data
    cout << "No KTP       = " << p->NOKTP << endl;
    cout << "Nama         = " << p->Nama << endl;
    cout << "Alamat       = " << p->Alamat.Jalan << ", " << p->Alamat.Kota << ", " << p->Alamat.KodePos << endl;
    cout << "Tanggal Lahir= " << p->Lahir.Tanggal << "/" << p->Lahir.Bulan << "/" << p->Lahir.Tahun << endl;

    cin.get();
}
